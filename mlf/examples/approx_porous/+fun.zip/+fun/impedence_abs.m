function ZA = impedence_abs(alpha_fun,beta_fun,omega, porosity, pore_mean_size, pore_standard_dev)

%alpha   = fun.dynamic_viscous_tortuosity(     omega, porosity, pore_mean_size, pore_standard_dev);
%beta    = fun.dynamic_thermal_compressibility(omega, porosity, pore_mean_size, pore_standard_dev);
alpha   = alpha_fun([omega, porosity, pore_mean_size, pore_standard_dev]);
beta    =  beta_fun([omega, porosity, pore_mean_size, pore_standard_dev]);
alpha   = alpha(:);
beta    = beta(:);
%
h   = .05;
Z0  = 348.84; %rho*c0 
c1  = 142800; %rho*gamma*P0  
c2  = 7.2857142857142855*1e-6; %rho/(gamma*P0) 
%Z   = -1i*sqrt(c1*alpha./beta).*coth(omega.*h.*sqrt(c2*alpha.*beta));
Z   = -1i*sqrt(c1*alpha./beta).*1./tanh(omega.*h.*sqrt(c2*alpha.*beta));
A   = 1-abs((Z-Z0)./(Z+Z0)).^2;
ZA  = [Z A];